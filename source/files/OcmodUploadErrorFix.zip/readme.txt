Install:
1. Place the file 'ocmod_upload_error_fix.ocmod.xml' into your system folder.
2. Go to the Admin section -> Extensions -> Modifications and click button 'Refresh' on the top right corner.
Complete.